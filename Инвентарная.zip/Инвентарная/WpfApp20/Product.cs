﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace WpfApp20
{
    // Класс, представляющий товар на складе
    public class Product : IDataErrorInfo
    {
        private int _quantity;
        private decimal _price;
        
        [Required(ErrorMessage = "ID обязателен")]
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Название товара обязательно")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Название должно содержать от 1 до 100 символов")]
        public string Name { get; set; }
        
        [StringLength(500, ErrorMessage = "Максимальная длина описания - 500 символов")]
        public string Description { get; set; }
        
        [Range(0, int.MaxValue, ErrorMessage = "Количество должно быть положительным числом")]
        public int Quantity 
        { 
            get => _quantity; 
            set
            {
                if (value < 0) 
                    throw new ArgumentException("Количество не может быть отрицательным");
                _quantity = value;
            }
        }
        
        [Range(0, 1000000000000, ErrorMessage = "Цена должна быть положительным числом (до триллиона)")]
        public decimal Price 
        { 
            get => _price; 
            set
            {
                if (value < 0)
                    throw new ArgumentException("Цена не может быть отрицательной");
                _price = value;
            }
        }
        
        [Required(ErrorMessage = "Категория товара обязательна")]
        public string Category { get; set; }
        
        public DateTime LastUpdated { get; set; }

        public Product()
        {
            LastUpdated = DateTime.Now;
        }

        public override string ToString()
        {
            return $"{Name} - {Quantity} шт.";
        }
        
        // Реализация интерфейса IDataErrorInfo для валидации
        public string Error => null;
        
        public string this[string propertyName]
        {
            get
            {
                string error = null;
                
                switch (propertyName)
                {
                    case nameof(Name):
                        if (string.IsNullOrWhiteSpace(Name))
                            error = "Название товара обязательно";
                        else if (Name.Length > 100)
                            error = "Название должно быть не более 100 символов";
                        break;
                    
                    case nameof(Quantity):
                        if (_quantity < 0)
                            error = "Количество должно быть положительным числом";
                        break;
                    
                    case nameof(Price):
                        if (_price < 0)
                            error = "Цена должна быть положительным числом";
                        else if (_price > 1000000000000)
                            error = "Цена не может превышать триллион";
                        break;
                    
                    case nameof(Category):
                        if (string.IsNullOrWhiteSpace(Category))
                            error = "Категория товара обязательна";
                        break;
                }
                
                return error;
            }
        }
        
        // Метод для валидации объекта
        public bool IsValid()
        {
            if (string.IsNullOrWhiteSpace(Name) || Name.Length > 100)
                return false;
                
            if (Description?.Length > 500)
                return false;
                
            if (Quantity < 0)
                return false;
                
            if (Price < 0 || Price > 1000000000000)
                return false;
                
            if (string.IsNullOrWhiteSpace(Category))
                return false;
                
            return true;
        }
    }
}