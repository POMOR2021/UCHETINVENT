using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace WpfApp20
{
    public class InputDialog : Window
    {
        private TextBox TB;
        public string ResponseText { get; private set; }
        private Regex validationRegex;
        private string validationMessage;
        private Label validationLabel;

        public InputDialog(string title, string question)
        {
            Title = title;
            Width = 300;
            Height = 200;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            var grid = new Grid { Margin = new Thickness(10) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var label = new Label { Content = question };
            Grid.SetRow(label, 0);
            grid.Children.Add(label);

            TB = new TextBox { Margin = new Thickness(0, 10, 0, 0) };
            TB.TextChanged += TB_TextChanged;
            Grid.SetRow(TB, 1);
            grid.Children.Add(TB);
            
            validationLabel = new Label { 
                Foreground = Brushes.Red, 
                Visibility = Visibility.Collapsed,
                Margin = new Thickness(0, 0, 0, 5)
            };
            Grid.SetRow(validationLabel, 2);
            grid.Children.Add(validationLabel);

            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 0, 0)
            };

            var okButton = new Button { Content = "OK", Width = 70, Margin = new Thickness(0, 0, 10, 0) };
            okButton.Click += (s, e) =>
            {
                if (IsInputValid())
                {
                    ResponseText = TB.Text;
                    DialogResult = true;
                    Close();
                }
            };

            var cancelButton = new Button { Content = "Отмена", Width = 70 };
            cancelButton.Click += (s, e) =>
            {
                DialogResult = false;
                Close();
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            Grid.SetRow(buttonPanel, 3);
            grid.Children.Add(buttonPanel);

            Content = grid;
        }
        
        public void SetNumericValidation(bool isInteger = true, bool allowNegative = false)
        {
            if (isInteger)
            {
                validationRegex = allowNegative 
                    ? new Regex(@"^-?\d+$") 
                    : new Regex(@"^\d+$");
                validationMessage = allowNegative 
                    ? "Введите целое число" 
                    : "Введите положительное целое число";
                
                TB.PreviewTextInput += (s, e) => {
                    e.Handled = !new Regex(allowNegative ? @"-?\d+" : @"\d+").IsMatch(e.Text);
                };
            }
            else
            {
                validationRegex = allowNegative 
                    ? new Regex(@"^-?\d+(\,\d*)?$") 
                    : new Regex(@"^\d+(\,\d*)?$");
                validationMessage = allowNegative 
                    ? "Введите число (например: 10,5)" 
                    : "Введите положительное число (например: 10,5)";
                
                TB.PreviewTextInput += (s, e) => {
                    e.Handled = !new Regex(allowNegative ? @"-?\d+(\,\d*)?" : @"\d+(\,\d*)?").IsMatch(e.Text);
                };
            }
            
            DataObject.AddPastingHandler(TB, (s, e) => {
                if (e.DataObject.GetDataPresent(typeof(string)))
                {
                    string text = (string)e.DataObject.GetData(typeof(string));
                    if (!validationRegex.IsMatch(text))
                    {
                        e.CancelCommand();
                    }
                }
            });
        }
        
        public void SetTextValidation(int minLength = 1, int maxLength = 100)
        {
            validationRegex = new Regex($"^.{{{minLength},{maxLength}}}$");
            validationMessage = $"Текст должен содержать от {minLength} до {maxLength} символов";
            TB.MaxLength = maxLength;
        }

        private void TB_TextChanged(object sender, TextChangedEventArgs e)
        {
            ValidateInput();
        }
        
        private bool ValidateInput()
        {
            if (validationRegex != null && !string.IsNullOrEmpty(TB.Text))
            {
                bool isValid = validationRegex.IsMatch(TB.Text);
                validationLabel.Content = isValid ? "" : validationMessage;
                validationLabel.Visibility = isValid ? Visibility.Collapsed : Visibility.Visible;
                TB.BorderBrush = isValid ? Brushes.Gray : Brushes.Red;
                return isValid;
            }
            return true;
        }
        
        private bool IsInputValid()
        {
            if (string.IsNullOrWhiteSpace(TB.Text))
            {
                validationLabel.Content = "Поле не может быть пустым";
                validationLabel.Visibility = Visibility.Visible;
                TB.BorderBrush = Brushes.Red;
                return false;
            }
            
            return ValidateInput();
        }
    }
} 