using System;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace WpfApp20
{
    // Класс для валидации пользовательского ввода
    public static class InputValidator
    {
        private static readonly Regex IntegerRegex = new Regex(@"^\d+$");
        private static readonly Regex NegativeIntegerRegex = new Regex(@"^-?\d+$");
        private static readonly Regex DecimalRegex = new Regex(@"^\d{1,13}(\,\d*)?$");
        private static readonly Regex NegativeDecimalRegex = new Regex(@"^-?\d{1,13}(\,\d*)?$");
        
        // Устанавливает валидацию для целочисленного поля ввода
        public static void SetIntegerValidation(TextBox textBox, bool allowNegative = false)
        {
            if (textBox == null)
                throw new ArgumentNullException(nameof(textBox));
                
            Regex validationRegex = allowNegative ? NegativeIntegerRegex : IntegerRegex;
            string tooltip = allowNegative 
                ? "Введите целое число" 
                : "Введите положительное целое число";
                
            textBox.ToolTip = tooltip;
            
            textBox.PreviewTextInput += (s, e) => {
                e.Handled = !Regex.IsMatch(e.Text, allowNegative ? "-?\\d+" : "\\d+");
                
                if (allowNegative && e.Text == "-" && 
                    (textBox.Text.Contains("-") || textBox.SelectionStart != 0))
                {
                    e.Handled = true;
                }
                
                if (!e.Handled && ((TextBox)s).Text.Length > 9)
                {
                    string potentialText = ((TextBox)s).Text.Insert(((TextBox)s).SelectionStart, e.Text);
                    if (!int.TryParse(potentialText.Replace("-", ""), out _))
                    {
                        e.Handled = true;
                    }
                }
            };
            
            // Запрет на вставку некорректных значений
            DataObject.AddPastingHandler(textBox, (s, e) => {
                if (e.DataObject.GetDataPresent(typeof(string)))
                {
                    string text = (string)e.DataObject.GetData(typeof(string));
                    if (!validationRegex.IsMatch(text) || 
                        (text.Replace("-", "").Length > 10 && !int.TryParse(text, out _)))
                    {
                        e.CancelCommand();
                    }
                }
            });
            
            // Обработка изменения текста для визуальной валидации
            textBox.TextChanged += (s, e) => {
                ValidateTextBox(textBox, validationRegex, tooltip);
            };
        }
        
        // Устанавливает валидацию для десятичного поля ввода
        public static void SetDecimalValidation(TextBox textBox, bool allowNegative = false)
        {
            if (textBox == null)
                throw new ArgumentNullException(nameof(textBox));
                
            Regex validationRegex = allowNegative ? NegativeDecimalRegex : DecimalRegex;
            string tooltip = allowNegative 
                ? "Введите число (до триллиона)" 
                : "Введите положительное число (до триллиона)";
                
            textBox.ToolTip = tooltip;
            
            textBox.PreviewTextInput += (s, e) => {
                e.Handled = !Regex.IsMatch(e.Text, allowNegative ? "-?[0-9,]" : "[0-9,]");
                
                if (allowNegative && e.Text == "-" && 
                    (textBox.Text.Contains("-") || textBox.SelectionStart != 0))
                {
                    e.Handled = true;
                }
                
                if (e.Text == "," && textBox.Text.Contains(","))
                {
                    e.Handled = true;
                }
                
                if (!e.Handled && e.Text.Contains("0123456789") && !e.Text.Contains(","))
                {
                    string wholePart = ((TextBox)s).Text;
                    int commaIndex = wholePart.IndexOf(',');
                    if (commaIndex >= 0)
                        wholePart = wholePart.Substring(0, commaIndex);
                    
                    if (wholePart.Length >= 13)
                    {
                        e.Handled = true;
                    }
                }
            };
            
            // Запрет на вставку некорректных значений
            DataObject.AddPastingHandler(textBox, (s, e) => {
                if (e.DataObject.GetDataPresent(typeof(string)))
                {
                    string text = (string)e.DataObject.GetData(typeof(string));
                    if (!validationRegex.IsMatch(text))
                    {
                        e.CancelCommand();
                    }
                }
            });
            
            textBox.TextChanged += (s, e) => {
                ValidateTextBox(textBox, validationRegex, tooltip);
                
                if (!string.IsNullOrEmpty(textBox.Text) && decimal.TryParse(textBox.Text, out decimal value))
                {
                    if (value > 1000000000000m)
                    {
                        textBox.BorderBrush = Brushes.Red;
                        ToolTip toolTip = new ToolTip { Content = "Значение не может превышать триллион" };
                        ToolTipService.SetToolTip(textBox, toolTip);
                    }
                }
            };
        }
        
        // Устанавливает валидацию для текстового поля
        public static void SetTextValidation(TextBox textBox, int minLength = 1, int maxLength = 100)
        {
            if (textBox == null)
                throw new ArgumentNullException(nameof(textBox));
                
            string tooltip = $"Текст должен содержать от {minLength} до {maxLength} символов";
            textBox.ToolTip = tooltip;
            textBox.MaxLength = maxLength;
            
            textBox.TextChanged += (s, e) => {
                if (string.IsNullOrEmpty(textBox.Text))
                {
                    textBox.BorderBrush = Brushes.Gray;
                    return;
                }
                
                bool isValid = textBox.Text.Length >= minLength;
                textBox.BorderBrush = isValid ? Brushes.Gray : Brushes.Red;
                
                if (!isValid)
                {
                    ToolTip toolTip = new ToolTip { 
                        Content = $"Текст должен содержать не менее {minLength} символов" 
                    };
                    ToolTipService.SetToolTip(textBox, toolTip);
                }
                else
                {
                    ToolTipService.SetToolTip(textBox, new ToolTip { Content = tooltip });
                }
            };
        }
        
        // Проверяет поле на соответствие шаблону
        private static void ValidateTextBox(TextBox textBox, Regex regex, string errorMessage)
        {
            if (string.IsNullOrEmpty(textBox.Text))
            {
                textBox.BorderBrush = Brushes.Gray;
                ToolTipService.SetToolTip(textBox, null);
                return;
            }
            
            bool isValid = regex.IsMatch(textBox.Text);
            textBox.BorderBrush = isValid ? Brushes.Gray : Brushes.Red;
            
            if (!isValid)
            {
                ToolTip toolTip = new ToolTip { Content = errorMessage };
                ToolTipService.SetToolTip(textBox, toolTip);
            }
            else
            {
                ToolTipService.SetToolTip(textBox, null);
            }
        }
        
        // Проверяет, является ли строка целым положительным числом
        public static bool IsPositiveInteger(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && IntegerRegex.IsMatch(input);
        }
        
        // Проверяет, является ли строка положительным десятичным числом
        public static bool IsPositiveDecimal(string input)
        {
            if (!string.IsNullOrWhiteSpace(input) && DecimalRegex.IsMatch(input))
            {
                // Дополнительная проверка на максимальное значение
                if (decimal.TryParse(input, out decimal value) && value <= 1000000000000m)
                {
                    return true;
                }
            }
            return false;
        }
        
        // Проверяет, является ли строка корректным числом
        public static bool IsValidNumber(string input, bool isInteger, bool allowNegative)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;
                
            if (isInteger)
                return allowNegative ? NegativeIntegerRegex.IsMatch(input) : IntegerRegex.IsMatch(input);
            else
            {
                if (allowNegative ? NegativeDecimalRegex.IsMatch(input) : DecimalRegex.IsMatch(input))
                {
                    // Дополнительная проверка на максимальное значение
                    if (decimal.TryParse(input, out decimal value) && value <= 1000000000000m)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
    }
} 