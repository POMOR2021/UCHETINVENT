﻿using System;
using System.Windows;
using System.Windows.Controls;
using WpfApp20;


namespace WpfApp20
{
    public partial class MainWindow : Window
    {
        private readonly InventoryService inventServ;
        private Product selectProd;

        public MainWindow()
        {
            InitializeComponent();
            inventServ = new InventoryService();
            InitializeInventoryLists();
            LoadCategories();
            RefrProductsList();
            
            // Добавление обработчиков для валидации ввода
            SetupInputValidation();

            // Проверяем наличие списков при запуске
            if (InventListCB.Items.Count == 0)
            {
                MessageBox.Show(
                    "У вас пока нет списков инвентаря.\nСоздайте новый список, чтобы начать работу.",
                    "Добро пожаловать",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }
        
        private void SetupInputValidation()
        {
            // Применяем валидаторы к текстовым полям
            InputValidator.SetTextValidation(NameTB, 1, 100);
            InputValidator.SetTextValidation(DescriptTB, 0, 500);
            InputValidator.SetIntegerValidation(QuantTB);
            InputValidator.SetDecimalValidation(PriceTB);
        }

        private void InitializeInventoryLists()
        {
            InventListCB.ItemsSource = inventServ.GetAvailableLists();
            if (InventListCB.Items.Count > 0)
            {
                InventListCB.SelectedIndex = 0;
            }
        }

        // Обновление списка товаров
        private void RefrProductsList()
        {
            ProdGrid.ItemsSource = inventServ.GetAllProducts();
        }

        // Очистка формы
        private void ClearForm()
        {
            NameTB.Text = "";
            DescriptTB.Text = "";
            QuantTB.Text = "";
            PriceTB.Text = "";
            CategoryCB.Text = "";
            selectProd = null;
        }

        // Загрузка категорий в ComboBox и ListBox
        private void LoadCategories()
        {
            var categories = inventServ.GetCategories();
            CategoryCB.ItemsSource = categories;
        }

        // Добавление новой категории
        private void AddCB_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(CategoryCB.Text))
            {
                MessageBox.Show("Введите название категории", "Ошибка", MessageBoxButton.OK);
                return;
            }

            try
            {
                inventServ.AddCategory(CategoryCB.Text);
                LoadCategories();
                MessageBox.Show("Категория успешно добавлена", "Отлчино", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении категории: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        // Проверка введенных данных
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(NameTB.Text))
            {
                MessageBox.Show("Введите название товара", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!InputValidator.IsPositiveInteger(QuantTB.Text))
            {
                MessageBox.Show("Введите корректное количество товара (целое положительное число)", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            if (!InputValidator.IsPositiveDecimal(PriceTB.Text))
            {
                MessageBox.Show("Введите корректную цену товара (положительное число)", "Ошибка", MessageBoxButton.OK);
                return false;
            }

            return true;
        }

        //Обработчик добавления товара
        private void AddBut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateInput())
                    return;

                var product = new Product
                {
                    Name = NameTB.Text,
                    Description = DescriptTB.Text,
                    Quantity = int.Parse(QuantTB.Text),
                    Price = decimal.Parse(PriceTB.Text),
                    Category = CategoryCB.Text
                };

                inventServ.AddProduct(product);
                RefrProductsList();
                LoadCategories(); 
                ClearForm();
                MessageBox.Show("Товар успешно добавлен", "Отлчино", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        //Обработчик сохранения изменений товара
        private void SaveBut_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (selectProd == null)
                {
                    MessageBox.Show("Выберите товар для редактирования", "Ошибка", MessageBoxButton.OK);
                    return;
                }

                if (!ValidateInput())
                    return;

                selectProd.Name = NameTB.Text;
                selectProd.Description = DescriptTB.Text;
                selectProd.Quantity = int.Parse(QuantTB.Text);
                selectProd.Price = decimal.Parse(PriceTB.Text);
                selectProd.Category = CategoryCB.Text;

                inventServ.UpdateProduct(selectProd);
                RefrProductsList();
                LoadCategories(); 
                ClearForm();
                MessageBox.Show("Товар успешно обновлен", "Отлично", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
            }
        }

        //Обработчик удаления товара
        private void DeleteBut_Click(object sender, RoutedEventArgs e)
        {
            if (selectProd == null)
            {
                MessageBox.Show("Выберите товар для удаления", "Ошибка", MessageBoxButton.OK);
                return;
            }

            var result = MessageBox.Show("Вы уверены, что хотите удалить этот товар?", "Подтверждение", 
                MessageBoxButton.YesNo);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    inventServ.DeleteProduct(selectProd.Id);
                    RefrProductsList();
                    ClearForm();
                    MessageBox.Show("Товар успешно удален", "Отлично", MessageBoxButton.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении товара: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        //Обработчик выбора товара в списке
        private void ProdGridSC(object sender, SelectionChangedEventArgs e)
        {
            selectProd = ProdGrid.SelectedItem as Product;
            if (selectProd != null)
            {
                NameTB.Text = selectProd.Name;
                DescriptTB.Text = selectProd.Description;
                QuantTB.Text = selectProd.Quantity.ToString();
                PriceTB.Text = selectProd.Price.ToString();
                CategoryCB.Text = selectProd.Category;
            }
        }

        //Обработчик поиска товаров
        private void SearchBoxTC(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                RefrProductsList();
            }
            else
            {
                ProdGrid.ItemsSource = inventServ.SearchProducts(SearchBox.Text);
            }
        }

        //Обработчик обновления списка товаров
        private void RefrButton_Click(object sender, RoutedEventArgs e)
        {
            RefrProductsList();
        }

        //Обработчик выбора списка инвентаря
        private void InventListCB_SChanged(object sender, SelectionChangedEventArgs e)
        {
            if (InventListCB.SelectedItem is string selectedList && !string.IsNullOrWhiteSpace(selectedList))
            {
                try
                {
                    inventServ.SwitchToList(selectedList);
                    LoadCategories(); 
                    RefrProductsList();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при переключении списка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        // Обработчик создания нового списка
        private void NewListBut_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new InputDialog("Новый список инвентаря", "Введите название нового списка:");
            dialog.SetTextValidation(3, 50); 
            
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    inventServ.CreateNewList(dialog.ResponseText);
                    InitializeInventoryLists();
                    RefrProductsList();
                    ClearForm();
                    MessageBox.Show("Новый список успешно создан", "Отлично", MessageBoxButton.OK);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при создании списка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                }
            }
        }

        // Обработчик удаления списка
        private void DeleteListBut_Click(object sender, RoutedEventArgs e)
        {
            if (InventListCB.SelectedItem is string selectedList)
            {
                var result = MessageBox.Show(
                    $"Вы точно хотите удалить список '{selectedList}'?\nСписок восстановлению не подлежит.",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        inventServ.DeleteList(selectedList);
                        InitializeInventoryLists();
                        RefrProductsList();
                        ClearForm();
                        MessageBox.Show("Список удален","Успешно", MessageBoxButton.OK);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка удаления списка: {ex.Message}", "Ошибка", MessageBoxButton.OK);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите список для удаления", "Ошибка", MessageBoxButton.OK);
            }
        }
    }
}