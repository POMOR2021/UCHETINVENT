using System;
using System.Globalization;
using System.Windows.Data;

namespace WpfApp20
{
    // Конвертер для сравнения числа со значением
    public class LessThanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return false;
                
            if (double.TryParse(value.ToString(), out double numValue) &&
                double.TryParse(parameter.ToString(), out double paramValue))
            {
                return numValue < paramValue;
            }
            
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    
    // Конвертер для сравнения числа со значением (больше чем)
    public class GreaterThanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return false;
                
            if (double.TryParse(value.ToString(), out double numValue) &&
                double.TryParse(parameter.ToString(), out double paramValue))
            {
                return numValue > paramValue;
            }
            
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    
    // Конвертер для сравнения числа со значением (равно)
    public class EqualsToConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return false;
                
            if (double.TryParse(value.ToString(), out double numValue) &&
                double.TryParse(parameter.ToString(), out double paramValue))
            {
                return Math.Abs(numValue - paramValue) < 0.0001;  
            }
            
            return value.Equals(parameter);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
} 