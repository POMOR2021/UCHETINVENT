﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using WpfApp20;

namespace WpfApp20
{
    // Сервис для управления инвентарем
    public class InventoryService
    {
        private List<Product> prod;
        private List<string> categories;
        private string currentListName;
        private readonly string baseDirectory = "списки инвентаря";
        private readonly Regex intRegex = new Regex(@"^\d+$"); 
        private readonly Regex decimalRegex = new Regex(@"^\d+(\,\d*)?$");
        
        // Конструктор сервиса управления инвентарем
        public InventoryService()
        {
            currentListName = null;
            categories = new List<string>();
            EnsureDirectoryExists();
            LoadData();
        }

        // Проверка и создание директории для хранения списков инвентаря
        private void EnsureDirectoryExists()
        {
            if (!Directory.Exists(baseDirectory))
            {
                Directory.CreateDirectory(baseDirectory);
            }
        }

        // Получение полного пути к файлу списка инвентаря
        private string GetFilePath(string listName)
        {
            return Path.Combine(baseDirectory, $"{listName}.json");
        }

        // Загрузка данных из файла
        private void LoadData()
        {
            try
            {
                if (string.IsNullOrEmpty(currentListName))
                {
                    prod = new List<Product>();
                    categories = new List<string>();
                    return;
                }

                string filePath = GetFilePath(currentListName);
                if (File.Exists(filePath))
                {
                    string jsonString = File.ReadAllText(filePath);
                    prod = JsonSerializer.Deserialize<List<Product>>(jsonString) ?? new List<Product>();
                    LoadCategories();
                }
                else
                {
                    prod = new List<Product>();
                    categories = new List<string>();
                }
            }
            catch (Exception)
            {
                prod = new List<Product>();
                categories = new List<string>();
            }
        }
        
        // Загрузка категорий из имеющихся товаров
        private void LoadCategories()
        {
            categories = prod
                .Where(p => !string.IsNullOrEmpty(p.Category))
                .Select(p => p.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();
        }

        // Сохранение данных в файл
        private void SaveData()
        {
            string filePath = GetFilePath(currentListName);
            string jsonString = JsonSerializer.Serialize(prod);
            File.WriteAllText(filePath, jsonString);
            LoadCategories();
        }

        // Получение списка доступных инвентарей
        public List<string> GetAvailableLists()
        {
            if (!Directory.Exists(baseDirectory))
                return new List<string>();

            return Directory.GetFiles(baseDirectory, "*.json")
                          .Select(f => Path.GetFileNameWithoutExtension(f))
                          .OrderBy(name => string.IsNullOrWhiteSpace(name)) 
                          .ThenBy(name => name)
                          .ToList();
        }

        // Переключение на другой список инвентаря
        public void SwitchToList(string listName)
        {
            if (string.IsNullOrWhiteSpace(listName))
                throw new ArgumentException("Название списка пустое");

            SaveData();
            currentListName = listName;
            LoadData();
        }

        // Создание нового списка инвентаря
        public void CreateNewList(string listName)
        {
            if (string.IsNullOrWhiteSpace(listName))
                throw new ArgumentException("Название списка пустое");

            if (File.Exists(GetFilePath(listName)))
                throw new ArgumentException("Список с таким названием уже существует");

            currentListName = listName;
            prod = new List<Product>();
            SaveData();
        }

        // Удаление списка инвентаря
        public void DeleteList(string listName)
        {
            if (string.IsNullOrWhiteSpace(listName))
                throw new ArgumentException("Название списка пустое");

            string filePath = GetFilePath(listName);
            if (!File.Exists(filePath))
                throw new ArgumentException("Список не найден");

            if (listName == currentListName)
            {
                currentListName = null;
                prod = new List<Product>();
                categories = new List<string>();
            }

            File.Delete(filePath);
        }
        
        // Валидация продукта
        public void ValidateProduct(Product product)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(product);
            
            if (!Validator.TryValidateObject(product, validationContext, validationResults, true))
            {
                string errorMessage = string.Join(Environment.NewLine, 
                    validationResults.Select(x => x.ErrorMessage));
                throw new ValidationException(errorMessage);
            }
            
            if (!product.IsValid())
            {
                throw new ValidationException("Продукт содержит недопустимые данные");
            }
        }

        // Добавление нового товара
        public void AddProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product));
                
            ValidateProduct(product);

            product.Id = prod.Any() ? prod.Max(p => p.Id) + 1 : 1;
            product.LastUpdated = DateTime.Now;
            prod.Add(product);
            SaveData();
        }

        // Обновление существующего товара
        public void UpdateProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product));
                
            ValidateProduct(product);

            var existingProduct = prod.FirstOrDefault(p => p.Id == product.Id);
            if (existingProduct == null)
                throw new ArgumentException($"Товар с ID {product.Id} не найден");

            existingProduct.Name = product.Name;
            existingProduct.Description = product.Description;
            existingProduct.Quantity = product.Quantity;
            existingProduct.Price = product.Price;
            existingProduct.Category = product.Category;
            existingProduct.LastUpdated = DateTime.Now;

            SaveData();
        }

        // Удаление товара
        public void DeleteProduct(int id)
        {
            var product = prod.FirstOrDefault(p => p.Id == id);
            if (product != null)
            {
                prod.Remove(product);
                SaveData();
            }
        }

        // Получение всех товаров
        public List<Product> GetAllProducts()
        {
            return prod.ToList();
        }

        // Поиск товаров по названию или описанию
        public List<Product> SearchProducts(string searchTerm)
        {
            return prod
                .Where(p => p.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                           p.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        // Получение списка категорий
        public List<string> GetCategories()
        {
            return categories.ToList();
        }
        
        // Добавление новой категории
        public void AddCategory(string category)
        {
            if (string.IsNullOrWhiteSpace(category))
                throw new ArgumentException("Название категории пустое");
                
            if (!categories.Contains(category, StringComparer.OrdinalIgnoreCase))
            {
                categories.Add(category);
                categories = categories.OrderBy(c => c).ToList();
            }
        }

        // Валидация числовых данных
        public bool ValidateNumericInput(string input, bool isInteger)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;
                
            return isInteger ? intRegex.IsMatch(input) : decimalRegex.IsMatch(input);
        }
        
        // Валидация текстовых данных
        public bool ValidateTextInput(string input, int minLength = 1, int maxLength = 100)
        {
            if (string.IsNullOrWhiteSpace(input))
                return false;
                
            return input.Length >= minLength && input.Length <= maxLength;
        }
    }
}